﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2Csharp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*2 -  Solicitar 5 números, ao fim, imprimir o número maior e o número menor.*/
            int numeros = 5;
            double maior = double.MinValue;
            double menor = double.MaxValue;

            for (int i = 1; i <= numeros; i++)
            {
                Console.WriteLine("Insira o " + i + "° número:");
                double numero = double.Parse(Console.ReadLine());

                // Verifica se o número inserido é o maior ou o menor
                if (numero > maior)
                {
                    maior = numero;
                }
                if (numero < menor)
                {
                    menor = numero;
                }
            }

            Console.WriteLine("O maior número é: " + maior);
            Console.WriteLine("O menor número é: " + menor);
            Console.ReadLine();
        }
    }
}
